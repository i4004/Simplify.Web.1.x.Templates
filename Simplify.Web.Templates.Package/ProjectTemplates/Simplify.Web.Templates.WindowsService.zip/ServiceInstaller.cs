﻿using System.ComponentModel;
using Simplify.WindowsServices;

namespace $safeprojectname$
{
	[RunInstaller(true)]
	public class ServiceInstaller : ServiceInstallerBase
	{
	}
}